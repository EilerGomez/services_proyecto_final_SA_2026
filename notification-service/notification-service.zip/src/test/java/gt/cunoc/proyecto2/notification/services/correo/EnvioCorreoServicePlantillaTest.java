package gt.cunoc.proyecto2.notification.services.correo;

import gt.cunoc.proyecto2.notification.models.Notificacion;
import gt.cunoc.proyecto2.notification.repositories.NotificacionRepository;
import jakarta.mail.Multipart;
import jakarta.mail.Session;
import jakarta.mail.internet.MimeMessage;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.Properties;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.MailSendException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/** enviarPlantilla: el método genérico que usan los correos de ventas y alquileres. */
@ExtendWith(MockitoExtension.class)
class EnvioCorreoServicePlantillaTest {

    private static final UUID EVENTO_ID = UUID.randomUUID();

    @Mock private NotificacionRepository notificaciones;
    @Mock private JavaMailSender correos;

    private EnvioCorreoService servicio;

    @BeforeEach
    void preparar() {
        servicio = new EnvioCorreoService(notificaciones, correos, "test@proyecto2.local");
    }

    @Test
    void sinCorreoNoRegistraNiEnvia() {
        // Act
        servicio.enviarPlantilla(EVENTO_ID, null, "COMPRA_BOLETO", "Asunto", "{}", "Cuerpo");
        servicio.enviarPlantilla(EVENTO_ID, "  ", "COMPRA_BOLETO", "Asunto", "{}", "Cuerpo");

        // Assert
        verifyNoInteractions(notificaciones, correos);
    }

    @Test
    void nuevaSeRegistraYSeEnvia() {
        // Arrange
        when(notificaciones.findByEventoIdAndDestinatarioAndPlantilla(EVENTO_ID, "ana@correo.com", "COMPRA_BOLETO"))
                .thenReturn(Optional.empty());
        ArgumentCaptor<Notificacion> guardada = ArgumentCaptor.forClass(Notificacion.class);
        ArgumentCaptor<SimpleMailMessage> enviado = ArgumentCaptor.forClass(SimpleMailMessage.class);

        // Act
        servicio.enviarPlantilla(EVENTO_ID, "ana@correo.com", "COMPRA_BOLETO", "Tu compra",
                "{\"total\":150.00}", "Hola Ana");

        // Assert
        verify(notificaciones).saveAndFlush(guardada.capture());
        verify(correos).send(enviado.capture());
        assertAll(
                () -> assertEquals("COMPRA_BOLETO", guardada.getValue().getPlantilla()),
                () -> assertEquals("{\"total\":150.00}", guardada.getValue().getDatos()),
                () -> assertEquals("ENVIADA", guardada.getValue().getEstado()),
                () -> assertEquals("Tu compra", enviado.getValue().getSubject()),
                () -> assertEquals("Hola Ana", enviado.getValue().getText()),
                () -> assertEquals("ana@correo.com", enviado.getValue().getTo()[0]));
    }

    @Test
    void yaEnviadaNoSeRepite() {
        // Arrange
        Notificacion previa = new Notificacion();
        previa.setEstado("ENVIADA");
        when(notificaciones.findByEventoIdAndDestinatarioAndPlantilla(EVENTO_ID, "ana@correo.com", "VENTA_CANCELADA"))
                .thenReturn(Optional.of(previa));

        // Act
        servicio.enviarPlantilla(EVENTO_ID, "ana@correo.com", "VENTA_CANCELADA", "Asunto", "{}", "Cuerpo");

        // Assert
        verify(correos, never()).send(any(SimpleMailMessage.class));
    }

    @Test
    void fallidaPreviaSeReintentaYSeMarcaEnviada() {
        // Arrange
        Notificacion previa = new Notificacion();
        previa.setEstado("FALLIDA");
        previa.setIntentos(1);
        when(notificaciones.findByEventoIdAndDestinatarioAndPlantilla(EVENTO_ID, "ana@correo.com", "COMPRA_BOLETO"))
                .thenReturn(Optional.of(previa));

        // Act
        servicio.enviarPlantilla(EVENTO_ID, "ana@correo.com", "COMPRA_BOLETO", "Tu compra", "{}", "Hola Ana");

        // Assert
        verify(correos).send(any(SimpleMailMessage.class));
        assertEquals("ENVIADA", previa.getEstado());
        assertEquals(2, previa.getIntentos());
    }

    @Test
    void conAdjuntoArmaUnCorreoMultiparte() throws Exception {
        // Arrange
        when(notificaciones.findByEventoIdAndDestinatarioAndPlantilla(EVENTO_ID, "ana@correo.com", "COMPRA_BOLETO"))
                .thenReturn(Optional.empty());
        MimeMessage mensaje = new MimeMessage(Session.getInstance(new Properties()));
        when(correos.createMimeMessage()).thenReturn(mensaje);
        byte[] pdf = "%PDF-1.4 boleto".getBytes(StandardCharsets.UTF_8);

        // Act
        servicio.enviarPlantilla(EVENTO_ID, "ana@correo.com", "COMPRA_BOLETO", "Tu compra", "{}", "Hola Ana",
                new AdjuntoCorreo("boleto-1234.pdf", pdf, "application/pdf"));
        mensaje.saveChanges();

        // Assert
        verify(correos).send(mensaje);
        Multipart partes = (Multipart) mensaje.getContent();
        assertAll(
                () -> assertEquals("Tu compra", mensaje.getSubject()),
                () -> assertTrue(mensaje.getContentType().startsWith("multipart/mixed")),
                () -> assertEquals(2, partes.getCount()),
                () -> assertEquals("boleto-1234.pdf", partes.getBodyPart(1).getFileName()),
                () -> assertTrue(partes.getBodyPart(1).getContentType().startsWith("application/pdf")));
    }

    @Test
    void falloSmtpConAdjuntoMarcaFallidaYPropaga() {
        // Arrange
        when(notificaciones.findByEventoIdAndDestinatarioAndPlantilla(EVENTO_ID, "ana@correo.com", "COMPRA_BOLETO"))
                .thenReturn(Optional.empty());
        when(correos.createMimeMessage()).thenReturn(new MimeMessage(Session.getInstance(new Properties())));
        doThrow(new MailSendException("sin red")).when(correos).send(any(MimeMessage.class));

        // Act + Assert
        assertThrows(MailSendException.class, () -> servicio.enviarPlantilla(EVENTO_ID, "ana@correo.com",
                "COMPRA_BOLETO", "Tu compra", "{}", "Hola Ana",
                new AdjuntoCorreo("boleto.pdf", new byte[] { 1, 2, 3 }, "application/pdf")));
        ArgumentCaptor<Notificacion> guardada = ArgumentCaptor.forClass(Notificacion.class);
        verify(notificaciones).save(guardada.capture());
        assertEquals("FALLIDA", guardada.getValue().getEstado());
    }
}